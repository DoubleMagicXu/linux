Linux第四次实验：正则表达式
运行：
 g++ main.cpp re.cpp
 ./a.out
